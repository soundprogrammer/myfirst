<html>
<head>
<style>
body {
background: url(https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2019/12/sale_24048_primary_image_wide-796x398.jpg); background-repeat: no-repeat; background-size:100%;
    }
    </style>
   <h1 style="color: white;">Efficient Test data management for Airline Passenger Management System</h1>
       <script>
function goBack() {
  window.history.back()
}</script>
           </head>
    <body>
        <div align="right">
<input type="button" value="GO BACK" onclick="goBack()"/>
</div>
        <?php
include 'db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM airplane_passengerdetails";
 
 
echo '<table bgcolor="White" border="5" cellspacing="10" cellpadding="2">  
      <tr> 
          <td> <font face="Arial" font color="Blue"> Airplane_id </font> </td> 
          <td> <font face="Arial" font color="Blue">Firstname</font> </td> 
          <td> <font face="Arial" font color="Blue">Lastname</font> </td> 
          <td> <font face="Arial" font color="Blue">Age</font> </td> 
      </tr>';
 

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $field1name = $row["Airplane_id"];
        $field2name = $row["Fname"];
        $field3name = $row["Lname"];
        $field4name = $row["Age"];
         echo '<tr> 
                  <td>'.$field1name.'</font></td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
              </tr>';
 
    }
} else {
    echo "0 results";
}
?>
</body>
    </html>