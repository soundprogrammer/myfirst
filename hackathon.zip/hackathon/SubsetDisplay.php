<html>
<head>

<style>
body {
background: url(https://www.hostinger.com/tutorials/wp-content/uploads/sites/2/2018/12/wordpress-database-plugins.jpg); background-repeat: no-repeat; background-size:100%;
    }

    #mySidenav a {
  position: absolute;
  left: -180px;
  transition: 0.3s;
  padding: 15px;
  width: 200px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 0 5px 5px 0;
}

#mySidenav a:hover {
  left: 0;
}

#Airplane_PassengerDetails{
  top: 100px;
  background-color: #4CAF50;
}

#Airplane_ChartTime {
  top: 200px;
  background-color: #2196F3;
}

#Airport_location {
  top: 300px;
  background-color: #f44336;
}
    .tooltip {
  position: relative;
  display: inline-block;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 130%;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  
  /* Position the tooltip */              
  position: absolute;
  z-index: 1;
  top: 100%;
  left: 50%;
  margin-left: -60px;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}

    </style>
    <h1 style="color: blue;">Efficient Test data management for Airline Passenger Management System</h1>

    <script>
function goBack() {
  window.history.back()
}
</script>
    </head>
    <body >
        <div align="right">
<input type="button" value="GO BACK" onclick="goBack()"/>
</div>
        <div id="mySidenav" class="sidenav">
  <a href="http://localhost/Hackathon/table1Display.php" id="Airplane_PassengerDetails">Airplane_Passenger</a>
  <a href="http://localhost/Hackathon/table2Display.php" id="Airplane_ChartTime">Airplane_ChartTime</a>
  <a href="http://localhost/Hackathon/table3Display.php" id="Airport_location">Airport_location</a>
</div>
        <div style="margin-left:80px;">&#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160; 
            <div class="tooltip" style="color:darkblue"><input type="button" style="padding: 6px 6px"; style="color: aqua" value=" TO DO DATA SUBSETING"/>
  <span class="tooltiptext" style="color:cadetblue" > Provide a data in source and target and view a table quiet better</span>
</div>
            </div>
         <div style="margin-top: 100px;" align='center'>
  <?php
include 'db_connection.php';
$conn = OpenCon();
 
 
// create a variable
$Source=$_POST['Source'];
$Target=$_POST['Target'];
             
             

 $sql="SELECT $Source .Airplane_id, $Source .Fname ,$Source .Lname ,$Source .Age , $Target.Arrival_time,$Target.Departure_time
FROM $Source
INNER JOIN $Target ON $Source .Airplane_id = $Target.Airplane_id;";

             echo '<table bgcolor="White" border="5" cellspacing="10" cellpadding="2">  
      <tr> 
          <td> <font face="Arial" font color="Blue"> Airplane_id </font> </td> 
          <td> <font face="Arial" font color="Blue"> Fname </font> </td> 
          <td> <font face="Arial" font color="Blue">Lname</font> </td> 
          <td> <font face="Arial" font color="Blue">Age</font> </td>
          <td> <font face="Arial" font color="Blue">Arrival_time Am</font> </td> 
          <td> <font face="Arial" font color="Blue">Departure_time Pm</font> </td> 
      </tr>';
             
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $field1name = $row["Airplane_id"];
        $field2name = $row["Fname"];
        $field3name = $row["Lname"];
         $field4name = $row["Age"];
      
        $field7name = $row["Arrival_time"];
        $field8name = $row["Departure_time"];
        
         echo '<tr> 
                  <td>'.$field1name.'</font></td> 
                  <td><font face="Arial" >'.$field2name.'</td> 
                  <td><font face="Arial">'.$field3name.'</td> 
                   <td>'.$field4name.'</font></td> 
                   
                   <td>'.$field7name.'</font></td> 
                  <td><font face="Arial" >'.$field8name.'</td> 
              </tr>';
} 
}
             else {
    echo "0 results";
}
?>
 
              </div>      
    </body></html>